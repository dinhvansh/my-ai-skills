# Procurement RFP HTML/PDF Skill

## Purpose

This skill creates polished vendor-facing RFP/RFQ documents from rough business requirements and exports them as professional HTML/PDF packages.

The primary output must be an A4-printable HTML document first. PDF is generated from the HTML after review. The HTML should look like a finished procurement document, not a rough markdown conversion.

Use this skill for:

- Generating a new RFP/RFQ document
- Rewriting an existing RFP into a cleaner vendor-facing version
- Converting business notes into a structured RFP
- Producing a printable HTML template
- Preparing a PDF-ready RFP package to send to vendors
- Creating a vendor proposal response checklist
- Creating the later shortlist/evaluation report structure

## Core Principle

Do not start by building a full procurement system.

For MVP, produce high-quality documents:

1. RFP input data
2. RFP HTML document
3. PDF export
4. Vendor response checklist
5. Optional shortlist report after proposals are received

The skill should standardize document quality, wording, structure, evidence, and evaluation criteria.

## Reference Style

Follow the user’s existing RFP sample style:

- A4 portrait layout
- White background
- Professional red accent color
- Cover block with document label, title, subtitle, date, deadline, and contact
- Revised/version notice block when needed
- Table of contents
- Numbered section headers
- Clean business typography
- Data tables with dark headers
- Callout boxes for warnings, important notes, and confidentiality
- Timeline/process blocks
- Checklist section for vendor submission
- Footer with confidential label
- Print-safe CSS using `@page`, page-break rules, and A4-friendly margins

## Required Output Modes

### Mode 1 — Generate RFP HTML

Use when the user provides rough requirements and wants a vendor-facing RFP.

Output:

- `rfp_document.html`
- Optional: `rfp_input.json`
- Optional: `vendor_submission_checklist.md`

### Mode 2 — Improve Existing RFP

Use when the user provides an existing RFP HTML, Word text, Markdown, or notes.

Output:

- Cleaned and redesigned HTML
- Improved structure
- Better wording
- More complete vendor instructions
- Print-ready CSS

### Mode 3 — Export RFP PDF

Use when the user asks to export the RFP.

Output:

- `rfp_document.pdf`
- Keep the HTML as the editable source of truth

### Mode 4 — Generate Shortlist Report

Use after vendors submit proposals.

Output:

- `vendor_shortlist_report.html`
- Optional PDF export
- Mandatory pass/fail matrix
- Weighted scoring matrix
- Recommended shortlist
- Risks and clarification questions

## Input Requirements

Accept rough input. Do not force the user to provide every field.

Recommended input fields:

```json
{
  "document_type": "RFP",
  "rfp_number": "RFP-YYYY-XXX",
  "version_label": "Draft / Revised / Final",
  "company_name": "Company Name",
  "project_title": "Project Title",
  "project_subtitle": "Short subtitle",
  "issue_date": "DD/MM/YYYY",
  "submission_deadline": "DD/MM/YYYY, HH:mm",
  "contact_name": "Contact Person",
  "contact_email": "email@company.com",
  "contact_phone": "+84 xxx xxx xxx",
  "company_address": "Company Address",
  "project_background": "Business context",
  "business_objectives": [],
  "technical_objectives": [],
  "current_state": [],
  "pain_points": [],
  "scope_of_work": [],
  "out_of_scope": [],
  "mandatory_requirements": [],
  "technical_requirements": [],
  "commercial_requirements": [],
  "budget": "Budget range",
  "payment_terms": [],
  "evaluation_criteria": [],
  "project_timeline": [],
  "submission_instructions": {},
  "confidentiality_note": "Confidentiality statement"
}
```

If data is missing, generate a best-effort RFP and mark missing items as placeholders like `[To be confirmed]`.

## Standard RFP Sections

Generate sections in this order unless the user requests a different structure:

1. Cover
2. Version / Revised Notice, if applicable
3. Table of Contents
4. Project Overview
5. Objectives and Requirements
6. Current State / Existing Architecture
7. Technical Requirements
8. Scope of Work
9. Commercial and Cost Requirements
10. Evaluation Criteria
11. Project Timeline
12. Proposal Submission Requirements
13. Evaluation Process
14. Contact Information
15. Confidentiality
16. Appendix — Vendor Submission Checklist

## Section Rules

### 1. Cover

Must include:

- Document label: `Request for Proposal`, `Request for Quotation`, or user-specified label
- Version label: Draft / Revised / Final when applicable
- Project title
- Subtitle
- Issue date
- Submission deadline
- Contact email

### 2. Version Notice

Include this section when:

- The document is revised
- Scope changed
- Budget changed
- Deadline changed
- Vendors received a previous version

Format as a blue callout notice.

### 3. Table of Contents

Must be generated as a clean TOC box with numbered items.

Do not use JavaScript for TOC.

### 4. Project Overview

Include:

- Company introduction
- Project background
- Problem statement
- Purpose of the RFP

Write vendor-facing language. Avoid internal slang unless needed.

### 5. Objectives and Requirements

Separate:

- Business objectives
- Technical objectives
- Priority order

Priority order should be explicit if the user gives constraints such as cost, maintainability, scalability, performance, or familiar technology.

### 6. Current State

Use tables, bullet points, and optional ASCII diagram when useful.

Typical items:

- Existing systems
- Data sources
- Current architecture
- Data volume
- Users
- Pain points
- Constraints

### 7. Technical Requirements

Separate requirements into:

- Mandatory
- Flexible / Preferred
- Optional

Use direct, auditable requirement wording.

Good:

- Vendor must support scheduled jobs, incremental loading, error handling, and logging.

Avoid:

- Vendor should provide a good solution.

### 8. Scope of Work

Use phase-based list.

Each phase should include:

- Phase name
- Estimated duration
- Activities
- Deliverables
- Acceptance criteria when available

### 9. Cost Requirements

Include:

- Budget range
- Cost breakdown expectation
- Licensing requirement
- Operating cost requirement
- TCO period, usually 3 years
- Payment milestones

Require vendors to clearly separate:

- One-time cost
- Recurring cost
- License cost
- Implementation service
- Support cost
- Optional items

### 10. Evaluation Criteria

Always include a scoring table.

Default scoring model:

| Criteria | Weight |
|---|---:|
| Technical Solution | 40 |
| Cost / Commercial | 30 |
| Experience and Team | 20 |
| Timeline and Delivery | 10 |

Total must equal 100.

If the user provides another scoring model, use the user’s model.

Also include:

- Minimum score for consideration
- Shortlist threshold
- Tie-break logic if useful

### 11. Project Timeline

Use a timeline table with:

- Phase
- Duration
- Start date
- End date
- Milestone

If dates are unknown, use relative timing, for example `Week 1–2`.

### 12. Proposal Submission Requirements

Must include:

- Deadline
- Submission email
- Email subject format
- File format
- File naming convention
- Required appendix
- Clarification deadline

### 13. Evaluation Process

Include:

- Proposal submission deadline
- Technical review
- Shortlist
- Vendor presentation / Q&A
- Optional POC
- Final evaluation and negotiation
- Award announcement
- Project kickoff

### 14. Contact Information

Use a table.

If phone/address is missing, use placeholders.

### 15. Confidentiality

Always include a confidentiality callout for vendor-facing RFP documents.

Default wording:

> All information in this RFP is confidential and intended only for invited vendors. Vendors must not share the information with any third party and may use it only for preparing a proposal.

### 16. Appendix — Vendor Submission Checklist

Always include a checklist so vendors know exactly what to submit.

Default checklist:

- Executive Summary
- Technical Solution
- Implementation Plan
- Cost Proposal
- Company Profile and Experience
- Team Structure and CVs
- Customer References
- Terms and Conditions
- Warranty and Support SLA
- Assumptions, Dependencies, and Exceptions

## HTML Design Rules

Use a complete standalone HTML file.

Requirements:

- Include `<!DOCTYPE html>`
- Include `<html lang="vi">` for Vietnamese documents, `<html lang="en">` for English documents
- Use embedded CSS in `<style>`
- Use A4 print setup with `@page`
- Avoid external JavaScript
- Avoid layout that depends on online assets
- Avoid overdesigned backgrounds that break in PDF
- Keep tables readable in PDF
- Use page-break rules for headings, tables, and callouts
- Use professional colors, preferably red/white/black unless user asks otherwise
- Keep document printable in browser and PDF renderer

Recommended CSS variables:

```css
:root {
  --ink: #1a1a1a;
  --ink-muted: #5a5a5a;
  --ink-faint: #8a8a8a;
  --red: #b92b27;
  --red-light: #f9e9e8;
  --rule: #e0e0e0;
  --bg: #ffffff;
  --bg-alt: #f7f7f7;
  --blue-pale: #eaf1fb;
  --blue-mid: #3b6cb7;
  --gold: #b87e2b;
  --gold-pale: #fdf5e6;
}
```

Recommended page setup:

```css
@page {
  margin: 2.2cm 2.5cm;
  size: A4 portrait;
}

@media print {
  body { font-size: 11pt; }
  .page { padding: 0; }
  .section-header { page-break-after: avoid; }
  h2, h3 { page-break-after: avoid; }
  .data-table, pre, .callout { page-break-inside: avoid; }
}
```

## PDF Export Rules

HTML is the source of truth.

When exporting to PDF:

- Preserve A4 layout
- Preserve margins
- Preserve table readability
- Do not cut tables awkwardly when avoidable
- Ensure Vietnamese fonts render correctly
- Check page breaks
- Check footer and confidential label
- Check links and email addresses

Preferred export method:

1. Render HTML in Chromium/Playwright
2. Print to PDF with A4
3. Use background graphics enabled
4. Verify PDF visually if possible

If browser-based export is not available, use a PDF renderer that supports CSS well.

## Language Rules

Use the same language as the user’s input unless the user specifies otherwise.

For Vietnamese RFPs:

- Use professional Vietnamese
- Keep common technical terms in English when they are standard: Data Warehouse, ETL/ELT, Power BI, API, SLA, backup, monitoring
- Avoid overly casual wording in the final RFP
- Use `Vendor` or `Nhà cung cấp` consistently; do not mix randomly

For bilingual documents:

- Put Vietnamese first, English second, unless the user asks otherwise
- Avoid doubling the document length unnecessarily
- Use bilingual labels only for important headings and submission instructions

## Data Handling Rules

Do not invent business facts.

If missing:

- Mark as `[To be confirmed]`
- Or write a neutral placeholder

If budget is unclear:

- Add a cost proposal section requiring vendors to provide detailed cost breakdown
- Do not create fake budget numbers

If timeline is unclear:

- Use `Estimated` or `Proposed by vendor`

If contact info is incomplete:

- Use placeholders

If confidential or personal data appears:

- Keep only what is necessary for the vendor-facing document
- Avoid exposing unnecessary internal details

## Requirement Quality Rules

Turn rough notes into clear, testable requirements.

Each major requirement should be:

- Specific
- Measurable when possible
- Vendor-answerable
- Easy to evaluate later

Poor:

- Need good reporting performance.

Better:

- Complex Power BI report queries should return within 5 seconds for normal business users under expected concurrency.

## Vendor Response Format

Always tell vendors how to answer.

Require vendor proposal to include:

1. Executive Summary
2. Technical Solution
3. Architecture Diagram
4. Implementation Plan
5. Project Timeline
6. Resource Plan
7. Risk and Mitigation
8. Cost Breakdown
9. Licensing and TCO
10. Company Experience
11. Team CVs
12. References
13. Warranty and SLA
14. Assumptions and Exceptions

## Shortlist Linkage

When generating an RFP, make it easy to evaluate later.

For every evaluation criterion, write clear expectations so the later Vendor Shortlist Skill can score proposals.

Example:

- Technical Solution: architecture fit, technology maturity, security, scalability, maintainability
- Cost: total cost, licensing transparency, operating cost, value for money
- Experience: similar projects, team capability, references
- Timeline: feasibility, project plan quality, risk management, handover

## Output Package Naming

Default file names:

- `RFP_[ProjectName]_[YYYYMMDD].html`
- `RFP_[ProjectName]_[YYYYMMDD].pdf`
- `RFP_Input_[ProjectName]_[YYYYMMDD].json`
- `Vendor_Checklist_[ProjectName]_[YYYYMMDD].md`
- `Shortlist_Report_[ProjectName]_[YYYYMMDD].html`

Clean file names by removing special characters and replacing spaces with underscores.

## Quality Checklist Before Final Output

Before finalizing, check:

- Cover page has title, date, deadline, contact
- TOC matches major sections
- Requirements are clear and grouped
- Evaluation criteria total equals 100
- Submission instructions are complete
- Confidentiality section exists
- Tables fit A4
- CSS is embedded
- No external JavaScript dependency
- No unsupported fonts required
- Placeholders are clearly marked
- HTML can be opened locally
- PDF export is visually clean

## Final Response Style

When replying to the user after generating files:

- Give direct download links
- Mention HTML is editable source
- Mention PDF is vendor-facing output
- Briefly list what was included
- Do not over-explain

Example:

> Xong rồi m. Tao đã tạo bộ RFP gồm HTML gốc và PDF để gửi vendor. HTML là file chỉnh sửa, PDF là bản gửi chính thức.

## Do Not

- Do not output only Markdown when the user asks for vendor-facing RFP
- Do not create plain text RFP unless requested
- Do not rely on external CSS/JS for the final HTML
- Do not hide missing data
- Do not let AI make final procurement decisions
- Do not create fake vendor claims, fake dates, or fake budget
- Do not produce messy HTML with inline random styles unless the user specifically asks for inline-only HTML
