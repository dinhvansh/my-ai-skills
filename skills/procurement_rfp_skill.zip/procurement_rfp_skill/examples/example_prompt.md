Use Procurement RFP HTML/PDF Skill.

Task:
Create a vendor-facing RFP as a polished A4 HTML document, then prepare it for PDF export.

Input:
- Company: [Company Name]
- Project: [Project Name]
- Issue date: [DD/MM/YYYY]
- Submission deadline: [DD/MM/YYYY, HH:mm]
- Contact: [Name / Email / Phone]
- Background: [Paste rough notes]
- Current state: [Paste systems/data/process notes]
- Scope: [Paste required scope]
- Mandatory requirements: [Paste list]
- Technical requirements: [Paste list]
- Budget: [Paste budget or say unknown]
- Evaluation criteria: [Paste scoring weights or use default 40/30/20/10]
- Timeline: [Paste target timeline or ask vendor to propose]

Output:
1. rfp_document.html
2. rfp_input.json
3. vendor_submission_checklist.md

Style:
Follow the red/white professional A4 RFP style with cover, revised notice if needed, TOC, numbered sections, tables, callouts, checklist, and confidential footer.
